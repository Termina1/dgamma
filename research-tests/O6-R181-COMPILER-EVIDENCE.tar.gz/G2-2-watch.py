import json, pathlib, signal, subprocess
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma')
with open('/tmp/dgamma-r181/G2-2.runner','w') as out:
 p=subprocess.Popen(['python3','-I','research-tests/run-r181-check.py','G2-2','research-tests/DGamma/R181O19Independence.idr'],cwd=root,stdout=out,stderr=subprocess.STDOUT)
 try:
  p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  print('Supervisor 150s cap: signal owned harness to kill compiler group and persist interruption',flush=True)
  p.send_signal(signal.SIGTERM)
  p.wait(timeout=30)
print(json.load(open('/tmp/dgamma-r181/G2-2.json')),flush=True)
