from pathlib import Path
import json
D=json.loads(Path('/tmp/dgamma-r188/actual-expressions.json').read_text())
COMMON='nameEq keyEq protocol swap source blocks premises safety unique'
P='(actorPrefix swap)'; SUF='(actorSuffix swap)'; L='(actorLeft swap)'; R='(actorRight swap)'
ST=f'({L} :: {R} :: {SUF})'; TT=f'({R} :: {L} :: {SUF})'
TRACE=f'(cursorTrace (columnCursor {D["run"]}))'
U=f'(o19ActualTargetUnique {COMMON})'; M=f'(o19ActualMovedAbsoluteCounts {COMMON})'
def site(role,member=''):
 return 'O19Site'+role if role in ['Right','Left'] else f'(O19Site{role} {member})'
def typ(actor): return f'O19SwapSite {P} {L} {R} {SUF} {actor}'
def actual(role,member=''): return f'(o19ActualBlockAtSite {COMMON} {site(role,member)})'
def raw_actual(site_text):return f'(o19ActualBlockAtSite {COMMON} {site_text})'
def sm(role,actor,member=''):
 if role in ['Right','Left']:return f'(safety{role}InOrder safety)'
 inj=f'(fst (o19ElemAppendInjections {P} {ST}) {member})' if role=='Before' else f'(snd (o19ElemAppendInjections {P} {ST}) (There (There {member})))'
 return f'(replace {{p = Elem {actor}}} (sym (actorBeforeExact swap)) {inj})'
def orig(role,actor,member=''):return f'(decomposedBlock blocks {actor} {sm(role,actor,member)})'
def before_replace(a,b,equation,proof):return f'(replace {{p = BeforeIn {a} {b}}} {equation} {proof})'
def anchored(role,actor,member):
 if role=='Before':
  order=before_replace(actor,L,'(sym (actorBeforeExact swap))',f'(o19BeforeAppendedSelected {P} {L} ({R} :: {SUF}) {member})')
  return f'(decomposedBlocksFollowOrder blocks {actor} {L} {sm(role,actor,member)} (safetyLeftInOrder safety) {order})'
 order=before_replace(R,actor,'(sym (actorBeforeExact swap))',f'(o19BeforeInPrepend {P} (BeforeThere (BeforeHere {member})))')
 return f'(decomposedBlocksFollowOrder blocks {R} {actor} (safetyRightInOrder safety) {sm(role,actor,member)} {order})'
def counts(role,actor,member):return f'(o19ActualUntouched{role}Counts {COMMON} {actor} {orig(role,actor,member)} {anchored(role,actor,member)})'
def start(role,actor,member=''):
 if role=='Right':return f'(fst {M})'
 if role=='Left':return f'(fst (snd {M}))'
 return f'(fst {counts(role,actor,member)})'
def end(role,actor,member=''):
 if role=='Left':return f'(snd (snd (snd {M})))'
 return f'(snd (snd {counts(role,actor,member)}))'
def bound(eRole,eActor,eMem,lRole,lActor,lMem,order):
 ordered=f'(decomposedBlocksFollowOrder blocks {eActor} {lActor} {sm(eRole,eActor,eMem)} {sm(lRole,lActor,lMem)} {order})'
 return f'(o19OrderedBoundaryLTE source {orig(eRole,eActor,eMem)} {orig(lRole,lActor,lMem)} {ordered})'
def pairs(eqEnd,eqStart,b):return f'(replace {{p = \\ends => LTE (fst ends) (snd ends)}} (sym (cong2 MkPair {eqEnd} {eqStart})) {b})'
def physical(eRole,eMem,lRole,lMem,b):return f'o19BlockBeforeByCount {TRACE} {actual(eRole,eMem)} {actual(lRole,lMem)}\n    {b}'
def out_type(early,late,eSite,lSite):return f'  BlockBefore name key world error value nameEq keyEq {TRACE}\n    {early} {late} {raw_actual(eSite)} {raw_actual(lSite)}\n'
def source_across(a,b,am,bm):
 return before_replace(a,b,'(sym (actorBeforeExact swap))',f'(o19BeforeAcrossAppend {P} {ST} {am} (There (There {bm})))')
def target_reverse(a,b,proof):return before_replace(a,b,'(sym (actorAfterExact swap))',proof)
def impossible(reverse):return f'void (o19BeforeAsymmetric {U} ordered {reverse})'
def row_before():
 name='o19ActualBeforeSiteOrder'
 text='\n||| FULL physical target order for a before-pair actor against all four\n||| later sites. Actual inequalities are discharged from original order and\n||| OWN absolute counts; no target boundary inequality is an input.\nexport\n'+D['header'].replace('o19ActualGlobalOriginProductCount',name)
 text+=f'  {{early, late : name}} -> (earlyMember : Elem early {P}) ->\n  (lateSite : {typ("late")}) -> BeforeIn early late targetOrder ->\n'+out_type('early','late',site('Before','earlyMember'),'lateSite')
 uq=f'(replace {{p = UniqueKeys}} (actorAfterExact swap) {U})'
 order=before_replace('early','late','(sym (actorBeforeExact swap))',f'(o19BeforeChangeSuffix {P} {TT} {ST} {uq} lateMember {before_replace("early","late","(actorAfterExact swap)","ordered")})')
 b=bound('Before','early','earlyMember','Before','late','lateMember',order)
 text+=f'{name} {{early}} {{late}} {COMMON} earlyMember (O19SiteBefore lateMember) ordered =\n  '+physical('Before','earlyMember','Before','lateMember',pairs(end('Before','early','earlyMember'),start('Before','late','lateMember'),b))+'\n'
 base=f'(o19OrderedBoundaryLTE source {orig("Before","early","earlyMember")} {D["left"]} {anchored("Before","early","earlyMember")})'
 for role in ['Right','Left']:
  b=base if role=='Right' else f'(transitive {base} (lteAddRight (transitionCount {D["earlier"]})))'
  text+=f'{name} {{early}} {COMMON} earlyMember O19Site{role} ordered =\n  '+physical('Before','earlyMember',role,'',pairs(end('Before','early','earlyMember'),start(role,R if role=='Right' else L),b))+'\n'
 b=bound('Before','early','earlyMember','After','late','lateMember',source_across('early','late','earlyMember','lateMember'))
 text+=f'{name} {{early}} {{late}} {COMMON} earlyMember (O19SiteAfter lateMember) ordered =\n  '+physical('Before','earlyMember','After','lateMember',pairs(end('Before','early','earlyMember'),start('After','late','lateMember'),b))+'\n'
 return text
def row_right():
 name='o19ActualRightSiteOrder'
 text='\n||| FULL physical target order from the moved-right site. Reversed/self\n||| positions contradict actual uniqueness; valid cases own their real bounds.\nexport\n'+D['header'].replace('o19ActualGlobalOriginProductCount',name)
 text+=f'  {{late : name}} -> (lateSite : {typ("late")}) -> BeforeIn {R} late targetOrder ->\n'+out_type(R,'late',site('Right'),'lateSite')
 reverse=target_reverse('late',R,f'(o19BeforeAppendedSelected {P} {R} ({L} :: {SUF}) lateMember)')
 text+=f'{name} {{late}} {COMMON} (O19SiteBefore lateMember) ordered =\n  {impossible(reverse)}\n'
 text+=f'{name} {COMMON} O19SiteRight ordered = {impossible("ordered")}\n'
 text+=f'{name} {COMMON} O19SiteLeft ordered = o19ActualMovedBlocksOrdered {COMMON}\n'
 b=f'(o19OrderedBoundaryLTE source {D["right"]} {orig("After","late","lateMember")} {anchored("After","late","lateMember")})'
 composed=f'(transitive (fst (snd (snd {M}))) {b})'
 b=f'(replace {{p = LTE (transitionCount (prefixThroughBlock {actual("Right")}))}} (sym {start("After","late","lateMember")}) {composed})'
 text+=f'{name} {{late}} {COMMON} (O19SiteAfter lateMember) ordered =\n  '+physical('Right','','After','lateMember',b)+'\n'
 return text
def all_sites():
 name='o19ActualSitesFollowOrder'
 text='\n||| ALL positional site pairs follow the ACTUAL target actor order. Every\n||| physical BlockBefore is constructed from derived absolute bounds on the\n||| SAME reached trace; impossible reverse/self cases use actual uniqueness.\nexport\n'+D['header'].replace('o19ActualGlobalOriginProductCount',name)
 text+=f'  {{early, late : name}} -> (earlySite : {typ("early")}) -> (lateSite : {typ("late")}) ->\n  BeforeIn early late targetOrder ->\n'+out_type('early','late','earlySite','lateSite')
 text+=f'{name} {COMMON} (O19SiteBefore earlyMember) lateSite ordered = o19ActualBeforeSiteOrder {COMMON} earlyMember lateSite ordered\n'
 text+=f'{name} {COMMON} O19SiteRight lateSite ordered = o19ActualRightSiteOrder {COMMON} lateSite ordered\n'
 reverse=target_reverse('late',L,f'(o19BeforeAcrossAppend {P} {TT} lateMember (There Here))')
 text+=f'{name} {{late}} {COMMON} O19SiteLeft (O19SiteBefore lateMember) ordered =\n  {impossible(reverse)}\n'
 reverse=target_reverse(R,L,f'(o19BeforeInPrepend {P} (BeforeHere Here))')
 text+=f'{name} {COMMON} O19SiteLeft O19SiteRight ordered =\n  {impossible(reverse)}\n'
 text+=f'{name} {COMMON} O19SiteLeft O19SiteLeft ordered = {impossible("ordered")}\n'
 b=f'(o19OrderedBoundaryLTE source {D["right"]} {orig("After","late","lateMember")} {anchored("After","late","lateMember")})'
 text+=f'{name} {{late}} {COMMON} O19SiteLeft (O19SiteAfter lateMember) ordered =\n  '+physical('Left','','After','lateMember',pairs(end('Left',L),start('After','late','lateMember'),b))+'\n'
 reverse=target_reverse('late','early',f'(o19BeforeAcrossAppend {P} {TT} lateMember (There (There earlyMember)))')
 text+=f'{name} {{early}} {{late}} {COMMON} (O19SiteAfter earlyMember) (O19SiteBefore lateMember) ordered =\n  {impossible(reverse)}\n'
 for role in ['Right','Left']:
  core='(BeforeHere (There earlyMember))' if role=='Right' else '(BeforeThere (BeforeHere earlyMember))'
  reverse=target_reverse(R if role=='Right' else L,'early',f'(o19BeforeInPrepend {P} {core})')
  text+=f'{name} {{early}} {COMMON} (O19SiteAfter earlyMember) O19Site{role} ordered =\n  {impossible(reverse)}\n'
 old=f'({P} ++ [{R}, {L}])'; new=f'({P} ++ [{L}, {R}])'
 te=f'(trans (actorAfterExact swap) (appendAssociative {P} [{R}, {L}] {SUF}))'
 se=f'(trans (actorBeforeExact swap) (appendAssociative {P} [{L}, {R}] {SUF}))'
 order=before_replace('early','late',f'(sym {se})',f'(o19BeforeChangePrefix {old} {new} {SUF} (replace {{p = UniqueKeys}} {te} {U}) earlyMember {before_replace("early","late",te,"ordered")})')
 b=bound('After','early','earlyMember','After','late','lateMember',order)
 text+=f'{name} {{early}} {{late}} {COMMON} (O19SiteAfter earlyMember) (O19SiteAfter lateMember) ordered =\n  '+physical('After','earlyMember','After','lateMember',pairs(end('After','early','earlyMember'),start('After','late','lateMember'),b))+'\n'
 return text
def full_target():
 name='o19ActualTargetBlocksFollowOrder'
 text='\n||| COMPLETE target-order BlockBefore field for the SAME actual reached\n||| block selector. Classifiers retain exact target enumeration occurrences.\nexport\n'+D['header'].replace('o19ActualGlobalOriginProductCount',name)
 text+=f'  (early, late : name) -> (earlyIn : Elem early targetOrder) -> (lateIn : Elem late targetOrder) ->\n  BeforeIn early late targetOrder ->\n  BlockBefore name key world error value nameEq keyEq {TRACE}\n    early late (o19ActualTargetBlock {COMMON} early earlyIn) (o19ActualTargetBlock {COMMON} late lateIn)\n'
 text+=f'{name} {COMMON} early late earlyIn lateIn ordered =\n  o19ActualSitesFollowOrder {COMMON}\n    (o19ClassifySwapSite {P} {L} {R} {SUF} (replace {{p = Elem early}} (actorAfterExact swap) earlyIn))\n    (o19ClassifySwapSite {P} {L} {R} {SUF} (replace {{p = Elem late}} (actorAfterExact swap) lateIn)) ordered\n'
 return text
