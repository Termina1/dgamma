# R190 read-only producer review

Performed while the single detached final-validation chain is active; no proof invocation or source change is part of this review. This is author self-review, NOT a replacement for the required independent reviewer gate.

## Selector

- o20GoalRank is executable, finite first-position rank with an absent-name sentinel. o20GoalMemberRankBound rules the sentinel out only for actual goal members; exact source/goal set matching is not claimed.
- o20BeforeRankCrossing authenticates the numeric orientation from BeforeIn and goal uniqueness. o20AdjacentInversionDrop lifts the R175 head drop through the entire untouched leading segment, accounting for its crossing contributions. o20ActorSwapMeasureDrop uses the same record's source/target equations.
- o20RealizeOrientedProgress calls the real closed O19 producer, deriving reached uniqueness and exact global decrease for that same choice. The repeated syntactically identical O19 term avoids a prohibited let alias; it is erased proof data, not a runtime efficiency claim.
- o20DescendFuel is structural induction on the actual inversion count. A positive result decrements by exactly one and reselects at the actual reached trace/blocks/full bundle/unique. The zero branch rejects any positive progress by contradiction. Nothing may occur at positive measure and is retained as blocked, not canonical.
- o20DescentStoppedPermutation folds the same finite path into its final state/trace/full blocks/bundle/unique, pure certificate and matching OperationalActorPermutation. O20DescentStep permits a certified positive choice generally; the concrete producer chooses the actual finite selector result. No theorem claims a particular candidate enumeration trace beyond that producer.
- Missing source/goal common supported-reference construction, finite inversion and actual safety-check completeness, and stoppedOrder=goal are explicit. In particular, the new search's goalState/LinearizesSupport inputs have not yet been instantiated for the public selector's inverse-renamed right target; these are not silently added public premises. No public selector body was attempted.
- A24's three concrete middle-swap elaboration failures remain unresolved. They are not a counterexample and were not recast as a successful negative test. No surviving concrete full search fixture is claimed.

## Convergence

- O20AllNameCut quantifies every raw name and retains ordered bindings, stronger than lookup-table equality. o20AllNameCutFirstThree projects exactly ambient, pointwise lookup and all-name controls. It requires an internal cut invariant, not an already proved canonical endpoint.
- Actual empty and insert successor producers generate all cut fields. The insertion lemma is about actual insertBinding outputs; orchestration/protocol/transition scheduling guards still belong to a whole paired execution.
- o20PairedReplaceControls proves owner and every foreign-name branch using actual lookup laws and bijection injectivity. There is no support restriction on the queried name.
- o20ObservedBeginsMetadata derives the real source components/parents from observed lookup equations and the internal all-name relation. B7's general projected-record component transport was reverted after 3 failures.
- The separately ratified shared-component boundary authenticates the common component by both real owner lookups and both successful resolver equations. Related views are derived using ordered effects and the right pairwise provision invariant; identity undo uses LocalStateRuntimeRelated, not function or erased-certificate equality.
- o20SharedObservedBeginCut consumes two actual checked Begin edges and their explicitly shared primitive observations; it derives all effects/controls at the actual outputs. It does not produce the general shared-observation adapter or select paired canonical cuts.
- Two nonempty fixtures derive a two-root cut from empty by insertion and then a full all-name cut after actual state2->3 Begin edges. These are genuine finite integration cases, not a full O20 run or a nontrivial renaming fixture.
- o20ClassifyReplayedBirth computes original child support. True preserves the existing supported bridge's entire exact occurrence/origin packet; False is explicitly O20UnsupportedBirth, neither a generated-birth proof nor an impossibility claim. The unsupported branch is still a theorem obligation.
- Whole paired Begin/Advance/Finish/gap alignment and endpoint induction are not supplied by the local successors. No convergence body or O21 work occurred.

## Guards and proof scope

All six new Idris files have %default total and %unbound_implicits off. New code has no holes, unsafe axioms, partiality, let/with/forbidden binding names, computed dependent-packet elimination, or new Either producer. Existing imported producers are reused without payload reconstruction. All proof interfaces/data are erased; only the rank computation is currently executable runtime capital. No plugin-runtime implementation or cold build is claimed.

Production src/ and dgamma.ipkg, CP3 blob, all five confluence entries, O19 Surface and LocalDiamond are unchanged. Existing four holes remain. Final checks are seeded and serialized; package success is a seeded build, not a forced rebuild of all 207 production modules.
