from pathlib import Path
header='''module DGamma.L2R3BarrierBlocks

import DGamma.Calculus
import DGamma.Coeffects
import DGamma.Metatheory
import DGamma.CP3
import DGamma.CP5ActorLifecycleOnlyExtended
import DGamma.L2R2SmallStates
import DGamma.L2R2SmallExecution
import DGamma.L2R3Attached
import DGamma.L2R3SmallAttached
import DGamma.L2R3BarrierStates
import DGamma.L2R3BarrierExecution
import Data.List.Elem
import Decidable.Equality

%default total
%unbound_implicits off
'''
actions=['LBegin 0','LAdvance 0','ORetire 1','ORemove 1','OInsert 3 Root (smallComponent True)','OInsert 4 Root (smallComponent False)','LBegin 2','LAdvance 2']
tags=['LBeginTag','LFinishTag','ORetireTag','ORemoveTag','OInsertTag','OInsertTag','LBeginTag','LFinishTag']
edges=['smallBegin0','smallFinish0','smallRetire1','smallRemove1','smallInsert3','insertS','beginFollowing','finishFollowing']
def proof(i):return f'({edges[i]} {"smallNativeExecution" if i<5 else "barrierNativeExecution"})'
def edge(i):return f'(Fired {{before = barrierState {i}}} {{afterState = barrierState {i+1}}} %search %search ({actions[i]}) {tags[i]} {proof(i)})'
def trace(a,b):return 'NoTransitions' if a==b else f'(MoreTransitions {edge(a)} {trace(a+1,b)})'
def installed(a,b):return '(InstalledEnd Refl)' if a==b else f'(InstalledStep {{first = barrierState {a}}} {{middle = barrierState {a+1}}} {{finalState = barrierState {b}}} ({actions[a]}) {tags[a]} {proof(a)} {trace(a+1,b)} Refl {installed(a+1,b)})'
def nolife(a,b):return 'NoLifecycleByEnd' if a==b else f'(NoLifecycleByStep {edge(a)} {trace(a+1,b)} (\\life, same => case same of Refl impossible) {nolife(a+1,b)})'
def extended(a,b):
 if a==b:return 'ExtendedLifecycleEnd'
 if a in [1,7]:return f'(ExtendedLifecycleStep {edge(a)} {trace(a+1,b)} Refl Refl {extended(a+1,b)})'
 fiber='(freshFiber (smallComponent True) (ChildOf 0))' if a==2 else '(retireFiber (freshFiber (smallComponent True) (ChildOf 0)))'
 return f'(ExtendedChild{"Retire" if a==2 else "Remove"}Step {edge(a)} {trace(a+1,b)} 1 {fiber} Refl Refl Refl {extended(a+1,b)})'
def occurrence(i,a,b):return f'(MkLocatedActionOccurrence (barrierState {i}) (barrierState {i+1}) {trace(a,i)} {edge(i)} {trace(i+1,b)} Refl Refl)'
