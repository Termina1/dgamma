from pathlib import Path
header='''module DGamma.L2R3SmallAttached

import DGamma.Calculus
import DGamma.Coeffects
import DGamma.Metatheory
import DGamma.CP3
import DGamma.CP5ActorLifecycleOnlyExtended
import DGamma.L2R2SmallStates
import DGamma.L2R2SmallExecution
import DGamma.L2R3Attached
import Data.List.Elem
import Decidable.Equality

%default total
%unbound_implicits off
'''
actions=['LBegin 0','LAdvance 0','ORetire 1','ORemove 1','OInsert 3 Root (smallComponent True)','LBegin 2','LAdvance 2']
tags=['LBeginTag','LFinishTag','ORetireTag','ORemoveTag','OInsertTag','LBeginTag','LFinishTag']
edges=['smallBegin0','smallFinish0','smallRetire1','smallRemove1','smallInsert3','smallBegin2','smallFinish2']
def edge(i):return f'(Fired {{before = smallState {i}}} {{afterState = smallState {i+1}}} %search %search ({actions[i]}) {tags[i]} ({edges[i]} smallNativeExecution))'
def trace(a,b):return 'NoTransitions' if a==b else f'(MoreTransitions {edge(a)} {trace(a+1,b)})'
def installed(a,b):return '(InstalledEnd Refl)' if a==b else f'(InstalledStep {{first = smallState {a}}} {{middle = smallState {a+1}}} {{finalState = smallState {b}}} ({actions[a]}) {tags[a]} ({edges[a]} smallNativeExecution) {trace(a+1,b)} Refl {installed(a+1,b)})'
def nolife(a,b):return 'NoLifecycleByEnd' if a==b else f'(NoLifecycleByStep {edge(a)} {trace(a+1,b)} (\\life, same => case same of Refl impossible) {nolife(a+1,b)})'
def extended(a,b):
 if a==b:return 'ExtendedLifecycleEnd'
 if a in [1,6]:return f'(ExtendedLifecycleStep {edge(a)} {trace(a+1,b)} Refl Refl {extended(a+1,b)})'
 fiber='(freshFiber (smallComponent True) (ChildOf 0))' if a==2 else '(retireFiber (freshFiber (smallComponent True) (ChildOf 0)))'
 return f'(ExtendedChild{"Retire" if a==2 else "Remove"}Step {edge(a)} {trace(a+1,b)} 1 {fiber} Refl Refl Refl {extended(a+1,b)})'
def occurrence(i,a,b):return f'(MkLocatedActionOccurrence (smallState {i}) (smallState {i+1}) {trace(a,i)} {edge(i)} {trace(i+1,b)} Refl Refl)'
if __name__=='__main__':
 content='''\n||| Native Remove1 at body ordinal2 releases True for Root3. The occurrence\n||| is in the SAME Finish0/Retire1/Remove1 core used by the attached fixture.\npublic export\n0 smallRelease : AttachedRelease Nat Bool Unit String (\\key => Unit) %search 0\n  '''+trace(1,4)+''' (smallComponent True)
smallRelease = MkAttachedRelease 1 (retireFiber (freshFiber (smallComponent True) (ChildOf 0)))
  '''+occurrence(3,1,4)+''' Refl Refl True Here Here
'''
 Path('research-tests/O6-L2R3-Sources/DGamma/L2R3SmallAttached.idr').write_text(header+content)
