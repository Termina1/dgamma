import json
import pathlib
import subprocess
import sys
root = pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma')
checks = [
 ('V01', 'research-tests/DGamma/R182O19AllFourCrossingsPositive.idr'),
 ('V02', 'research-tests/DGamma/R182O19RevisedSafetyPositive.idr'),
 ('V03', 'research-tests/DGamma/R182O19RevisedSafetyNegative.idr'),
 ('V04', 'research-tests/DGamma/R182O19AdjacencyNegative.idr'),
 ('V05', 'research-tests/DGamma/R183O19GenericBeginRowPositive.idr'),
 ('V06', 'research/DGamma/CP5O20CanonicalPairSelectionSpike.idr'),
 ('V07', 'research/DGamma/CP5O19CommutedDomainSpike.idr'),
 ('V08', 'research/DGamma/CP5O19ActualCommutedDomainSpike.idr'),
 ('V09', 'research/DGamma/CP5O19OpeningPropagationSpike.idr'),
 ('V10', 'research/DGamma/CP5O19ActivationRowSpike.idr'),
 ('V11', 'research/DGamma/CP5O19CartesianCursorSpike.idr'),
 ('V12', 'research/DGamma/CP5ConfluenceCanonicalSortSpike.idr'),
 ('V13', 'research/DGamma/CP5ConfluenceCrossTraceSpike.idr'),
 ('V14', 'research/DGamma/CP5ConfluenceRenamingCompositionSpike.idr'),
 ('V15', 'research/DGamma/CP5ConfluenceDeletionChainSpike.idr'),
 ('V16', 'research/DGamma/CP5ConfluenceLocalDiamondSpike.idr'),
 ('V17', 'package'),
]
for unit, path in checks:
    with pathlib.Path('/tmp/dgamma-r183', unit+'.runner').open('w') as log:
        result = subprocess.run([sys.executable, '-I', 'research-tests/run-r183-check.py', unit, path], cwd=root, stdout=log, stderr=subprocess.STDOUT)
    record = json.loads(pathlib.Path('/tmp/dgamma-r183', unit+'.json').read_text())
    print(unit, record['passed'], record['fresh'], record['seconds'], flush=True)
    if result.returncode or not record['passed'] or not record['fresh']:
        raise SystemExit('STOP: failed regression '+unit)
print('ALL17 REGRESSIONS PASS', flush=True)
