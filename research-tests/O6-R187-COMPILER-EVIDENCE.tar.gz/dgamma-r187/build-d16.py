from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19CartesianColumnsSpike.idr');s=p.read_text();name='o19CartesianColumns';start=s.index('export\n0 '+name+' :');dstart=s.index('\n'+name+' {before}',start);end=s.index('\n||| Instantiate the checked',dstart)
sig=s[start:dstart].replace('0 '+name+' :','0 '+name+'Sites :');body=s[dstart:end]
for old,new in [
('  UniqueRawNameInsertions name key world error value nameEq keyEq original ->','  (unique : UniqueRawNameInsertions name key world error value nameEq keyEq original) ->'),
('  (appendTransitions earlier residual = cursorTrace current) ->','  (decomposition : appendTransitions earlier residual = cursorTrace current) ->'),
('  (o19ActionWord residual = (leftHead :: leftTail) ++ (remainingRight ++ suffixWord)) ->','  (exact : o19ActionWord residual = (leftHead :: leftTail) ++ (remainingRight ++ suffixWord)) ->'),
('  ((action : Action name key value world error) -> Elem action remainingRight -> Elem action fullRightWord) ->','  (rightMembers : (action : Action name key value world error) -> Elem action remainingRight -> Elem action fullRightWord) ->')]:
 assert old in sig,old
 sig=sig.replace(old,new)
last=sig.rindex('  O19ColumnRun name key world error value protocol nameEq keyEq (cursorTrace current) earlier')
sig=sig[:last]+'''  (o19CrossingSites (cursorDerivation (columnCursor (o19CartesianColumns nameEq keyEq protocol swap original blocks premises safety unique leftHead leftTail fullRightWord suffixWord remainingRight originalClasses current earlier residual decomposition exact rightMembers))) =
    o19ColumnSites (transitionCount earlier) (length (leftHead :: leftTail)) (length remainingRight))'''
step=body[body.index('\n'+name+' nameEq'):].rstrip()
begin=step.index('(\\next,');depth=0;finish=None
for i in range(begin,len(step)):
 if step[i]=='(': depth+=1
 if step[i]==')':
  depth-=1
  if depth==0:
   finish=i+1;break
assert finish==len(step),(finish,len(step))
proof=step[begin:finish].replace('o19CartesianColumns nameEq','o19CartesianColumnsSites nameEq',1)
step=step.replace('\n'+name+' nameEq','\n'+name+'Sites nameEq',1).replace('    o19ColumnAtWordCut nameEq','    o19ColumnAtWordCutSites nameEq',1)
newbody='''
o19CartesianColumnsSites nameEq keyEq protocol swap original blocks premises safety unique leftHead leftTail fullRightWord suffixWord
  [] originalClasses current earlier residual decomposition exact rightMembers = Refl
'''+step+'\n      '+proof+'\n'
p.write_text((s+'\n||| EXACT site word of the ACTUAL Cartesian column algorithm, obtained by\n||| structural right-word induction and actual-row site equations. This is\n||| attached to the existing same produced run; no schedule/site oracle.\n'+sig+newbody).rstrip()+'\n')
