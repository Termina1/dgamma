import pathlib, subprocess, datetime, json
ROOT=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');OUT=pathlib.Path('/tmp/dgamma-r187')
items=[
('V5','research/DGamma/CP5ConfluenceDeletionChainSpike.idr'),
('V6','research/DGamma/CP5ConfluenceCanonicalSortSpike.idr'),
('V7','research/DGamma/CP5ConfluenceRenamingCompositionSpike.idr'),
('V8','research/DGamma/CP5ConfluenceCrossTraceSpike.idr'),
('V9','research/DGamma/CP5O19PaperBranchCompletenessSpike.idr'),
('V10','research/DGamma/CP5O19OrdinalPlanSpike.idr'),
('V11','research/DGamma/CP5O19CartesianSitePlanSpike.idr'),
('V12','research/DGamma/CP5O19CartesianWordRowSpike.idr'),
('V13','research/DGamma/CP5O19CartesianColumnsSpike.idr'),
('V14','research/DGamma/CP5O19CartesianNumericSpike.idr'),
('V15','research/DGamma/CP5O19ActualCartesianSpike.idr'),
('V16','research/DGamma/CP5O20LinearExtensionSpike.idr'),
('V17','research-tests/DGamma/R185O19ObservedInsertionRowPositive.idr'),
('V18','research-tests/DGamma/R185O19ActivationInsertionRowPositive.idr'),
('V19','research-tests/DGamma/R185O19InsertionGuardsPositive.idr'),
('V20','research-tests/DGamma/R182O19RevisedSafetyPositive.idr'),
('V21','research-tests/DGamma/R182O19RevisedSafetyNegative.idr'),
('V22','research-tests/DGamma/R182O19AdjacencyNegative.idr'),
('V23','research-tests/DGamma/R183O19GenericBeginRowPositive.idr'),
('V24','research-tests/DGamma/R182O19AllFourCrossingsPositive.idr'),
('V25','research-tests/DGamma/R7OperationalThreadingPositive.idr'),
('V26','research-tests/DGamma/R16ConfluenceTheoremAssemblyPositive.idr'),
('V27','research-tests/DGamma/R16EndpointControlsImpossibilityPositive.idr'),
('V28','research-tests/DGamma/R6SafetyDetachmentNegative.idr','firstPremises and secondPremises','detachSafetyFromCurrentState'),
('V29','research-tests/DGamma/R8ZeroDerivationOperationalStepNegative.idr','FiniteAdjacentSwapDerivation','zeroDerivationOperationalStepStillAccepted'),
('V30','research-tests/DGamma/R8FullPipeline.idr'),
('V31','package')]
for item in items:
 if item[1]!='package':
  p=ROOT/item[1];assert p.is_file() and p.stat().st_size>0,item
  assert p.read_text().startswith('module DGamma.'+p.stem+'\n'),item
 assert not (OUT/(item[0]+'.json')).exists(),item
v4=json.loads((OUT/'V4.json').read_text());assert v4['passed'] and v4['path']=='research/DGamma/CP5ConfluenceLocalDiamondSpike.idr' and v4['sourceSHA256']!='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
guard=datetime.datetime(2026,9,8,8,43,56,tzinfo=datetime.timezone.utc)
for item in items:
 assert datetime.datetime.now(datetime.timezone.utc)<guard,'08:43:56 guard: no new invocation'
 print('LAUNCH',item,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with (OUT/(item[0]+'.driver.log')).open('w') as f:
  result=subprocess.run(['python3','-I','research-tests/run-r187-check.py',*item],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',item[0],result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
print('FINAL BATCH COMPLETE',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
