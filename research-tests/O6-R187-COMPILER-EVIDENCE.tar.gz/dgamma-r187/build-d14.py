from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19CartesianColumnsSpike.idr');s=p.read_text();name='o19ColumnAfterRow';start=s.index('export\n0 '+name+' :');dstart=s.index('\n'+name+' nameEq',start);end=s.index('\n||| Consume an EXPLICIT',dstart)
sig=s[start:dstart].replace('0 '+name+' :','0 '+name+'Sites :');body=s[dstart:end]
sig=sig.replace('  (o19ActionWord spine = leftWord) -> (transitionCount spine = length leftWord) ->','  (leftExact : o19ActionWord spine = leftWord) -> (leftCount : transitionCount spine = length leftWord) ->').replace('  (transitionAction right = rightHead) -> (o19ActionWord later = remainingRight ++ suffixWord) ->','  (rightExact : transitionAction right = rightHead) -> (restExact : o19ActionWord later = remainingRight ++ suffixWord) ->')
last=sig.rindex('  O19ColumnRun name key world error value protocol nameEq keyEq (cursorTrace current) earlier')
sig=sig[:last]+'''  (0 rowSites : o19CrossingSites (cursorDerivation (mixedRowCursor (wordRow row))) = o19RowSites (transitionCount earlier) (length leftWord)) ->
  (0 smallerSites : (next : O19ReachedCursor name key world error value protocol nameEq keyEq original) ->
    {nextBefore : SystemState name key value world error} ->
    (nextEarlier : Transitions initial nextBefore) -> (nextRest : Transitions nextBefore (cursorFinal next)) ->
    (nextDecomposition : appendTransitions nextEarlier nextRest = cursorTrace next) ->
    (nextWord : o19ActionWord nextRest = leftWord ++ (remainingRight ++ suffixWord)) ->
    (o19CrossingSites (cursorDerivation (columnCursor (smallerColumns next nextEarlier nextRest nextDecomposition nextWord))) =
      o19ColumnSites (transitionCount nextEarlier) (length leftWord) (length remainingRight))) ->
  (o19CrossingSites (cursorDerivation (columnCursor (o19ColumnAfterRow nameEq keyEq protocol original current earlier spine right later leftWord rightHead remainingRight suffixWord row leftExact leftCount rightExact restExact smallerColumns))) =
    o19ColumnSites (transitionCount earlier) (length leftWord) (S (length remainingRight)))'''
rhs=body.split('=\n',1)[1].strip()
# This source suffix is exactly one parenthesized application.
tail=rhs[rhs.index('(smallerColumns '):].strip()
assert tail.startswith('(smallerColumns ') and tail.count('(')==tail.count(')'),tail
head=rhs.replace('o19ColumnPrepend ','o19ColumnPrependSites ',1)
proof=tail.replace('(smallerColumns ','(smallerSites ',1)
newbody='''
o19ColumnAfterRowSites nameEq keyEq protocol original current earlier spine right later leftWord rightHead remainingRight suffixWord
  row leftExact leftCount rightExact restExact smallerColumns rowSites smallerSites =
    trans ('''+head+''')
      (cong2 (++) rowSites
        (trans '''+proof+'''
          (cong (\\start => o19ColumnSites start (length leftWord) (length remainingRight))
            (transitionPrefixLength earlier (mixedRowRight (wordRow row))))))
'''
p.write_text((s+'\n||| Actual column sites from an explicit actual row and strictly smaller\n||| column induction hypothesis; no caller-supplied future operational row.\n'+sig+newbody).rstrip()+'\n')
