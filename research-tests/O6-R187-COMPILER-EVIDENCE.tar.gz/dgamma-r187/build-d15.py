from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19CartesianColumnsSpike.idr');s=p.read_text();name='o19ColumnAtWordCut';start=s.index('export\n0 '+name+' :');dstart=s.index('\n'+name+' nameEq',start);end=s.index('\n||| ACTUAL Cartesian',dstart)
sig=s[start:dstart].replace('0 '+name+' :','0 '+name+'Sites :');body=s[dstart:end]
for old,new in [
('  UniqueRawNameInsertions name key world error value nameEq keyEq original ->','  (unique : UniqueRawNameInsertions name key world error value nameEq keyEq original) ->'),
('  (appendTransitions earlier residual = cursorTrace current) ->','  (decomposition : appendTransitions earlier residual = cursorTrace current) ->'),
('  ((action : Action name key value world error) -> Elem action (rightHead :: remainingRight) -> Elem action fullRightWord) ->','  (rightMembers : (action : Action name key value world error) -> Elem action (rightHead :: remainingRight) -> Elem action fullRightWord) ->'),
('  O19WordCut name key world error value (leftHead :: leftTail) ((rightHead :: remainingRight) ++ suffixWord) residual ->','  (cut : O19WordCut name key world error value (leftHead :: leftTail) ((rightHead :: remainingRight) ++ suffixWord) residual) ->')]:
 assert old in sig,old
 sig=sig.replace(old,new)
last=sig.rindex('  O19ColumnRun name key world error value protocol nameEq keyEq (cursorTrace current) earlier')
sig=sig[:last]+'''  (0 smallerSites : (next : O19ReachedCursor name key world error value protocol nameEq keyEq original) ->
    {nextBefore : SystemState name key value world error} ->
    (nextEarlier : Transitions initial nextBefore) -> (nextRest : Transitions nextBefore (cursorFinal next)) ->
    (nextDecomposition : appendTransitions nextEarlier nextRest = cursorTrace next) ->
    (nextWord : o19ActionWord nextRest = (leftHead :: leftTail) ++ (remainingRight ++ suffixWord)) ->
    (o19CrossingSites (cursorDerivation (columnCursor (smallerColumns next nextEarlier nextRest nextDecomposition nextWord))) =
      o19ColumnSites (transitionCount nextEarlier) (length (leftHead :: leftTail)) (length remainingRight))) ->
  (o19CrossingSites (cursorDerivation (columnCursor (o19ColumnAtWordCut nameEq keyEq protocol swap original blocks premises safety unique leftHead leftTail fullRightWord suffixWord rightHead remainingRight originalClasses current earlier residual decomposition rightMembers cut smallerColumns))) =
    o19ColumnSites (transitionCount earlier) (length (leftHead :: leftTail)) (S (length remainingRight)))'''
# Extract the genuine row expression by balanced parentheses.
begin=body.index('(o19BubbleWordRow ');depth=0;finish=None
for i in range(begin,len(body)):
 if body[i]=='(': depth+=1
 if body[i]==')':
  depth-=1
  if depth==0:
   finish=i+1;break
assert finish
bubble=body[begin:finish]
proof=bubble.replace('(o19BubbleWordRow ','(o19BubbleWordRowSites ',1)
body=body.replace('\n'+name+' nameEq','\n'+name+'Sites nameEq').replace(' smallerColumns =',' smallerColumns smallerSites =').replace('    o19ColumnAfterRow nameEq','    o19ColumnAfterRowSites nameEq',1)
body=body.rstrip()+'''\n      (trans '''+proof+''' (cong (o19RowSites (transitionCount earlier)) count)) smallerSites\n'''
p.write_text((s+'\n||| Actual Cartesian site pattern at the explicitly observed source-word\n||| cut. The real row equation and strictly smaller column site IH suffice.\n'+sig+body).rstrip()+'\n')
