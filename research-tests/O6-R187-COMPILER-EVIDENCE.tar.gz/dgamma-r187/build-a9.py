from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19PaperBranchCompletenessSpike.idr')
s=p.read_text().replace('import DGamma.CP4DeletionSelectedForeignOrchestration','import DGamma.CP4DeletionSelectedForeignLifecycleDivert\nimport DGamma.CP4DeletionSelectedForeignLifecycleLeave\nimport DGamma.CP4DeletionSelectedForeignOrchestration')
s+='''
||| Classify the real checked lifecycle action when it neither unloads nor
||| reaches Unloading. Begin's actual tag and Advance's actual branch are
||| produced; Divert/Leave are contradicted by their exact producer-owned
||| endpoint equations. These two exclusions are discharged from a block below.
export
0 o19LifecyclePaperChecked :
  {name, key, world, error : Type} -> {value : key -> Type} ->
  (nameEq : DecEq name) -> (keyEq : DecEq key) ->
  (action : Action name key value world error) -> (tag : RuleTag) ->
  (before, afterState : SystemState name key value world error) ->
  (checked : checkedApplyAction @{nameEq} @{keyEq} action before = Just (tag, afterState)) ->
  (isLifecycleAction action = True) -> Not (action = LUnload (actionOwner action)) ->
  Not (unloadingEndpoint {name} {key} {value} {world} {error} @{nameEq} (actionOwner action) afterState = True) ->
  PaperActivationStep (Fired {before} {afterState} nameEq keyEq action tag checked)
o19LifecyclePaperChecked nameEq keyEq (OInsert actor parent component) tag before afterState checked lifecycle excluded notUnloading = void (uninhabited lifecycle)
o19LifecyclePaperChecked nameEq keyEq (ORetire actor) tag before afterState checked lifecycle excluded notUnloading = void (uninhabited lifecycle)
o19LifecyclePaperChecked nameEq keyEq (ORemove actor) tag before afterState checked lifecycle excluded notUnloading = void (uninhabited lifecycle)
o19LifecyclePaperChecked nameEq keyEq (LBegin actor) tag before afterState checked lifecycle excluded notUnloading =
  PaperBeginStep Refl (fst (lBeginBoundary nameEq keyEq actor before afterState tag checked))
o19LifecyclePaperChecked nameEq keyEq (LAdvance actor) tag before afterState checked lifecycle excluded notUnloading =
  o19PaperAdvanceNoUnloading nameEq keyEq actor before afterState tag checked notUnloading
    (advanceStructureTheorem nameEq keyEq actor before afterState tag
      (checkedActionProjects nameEq keyEq (LAdvance actor) before afterState tag checked))
'''
raw='(checkedActionProjects nameEq keyEq (LDivert actor) (MkSystemState ambient fibers) afterState tag checked)'
plan=f'(foreignDivertPlanView nameEq keyEq actor ambient fibers tag afterState {raw})'
s+=f'''o19LifecyclePaperChecked nameEq keyEq (LDivert actor) tag (MkSystemState ambient fibers) afterState checked lifecycle excluded notUnloading =
  void (notUnloading (divertUnloading (abortDivertStructureTheorem nameEq keyEq actor (MkSystemState ambient fibers) afterState
    (replace {{p = \\observedTag => applyAction @{{nameEq}} @{{keyEq}} (LDivert actor) (MkSystemState ambient fibers) = Just (observedTag, afterState)}}
      (foreignDivertPlanViewTag (divertPlanView {plan})) {raw}))))
'''
raw='(checkedActionProjects nameEq keyEq (LLeave actor) (MkSystemState ambient fibers) afterState tag checked)'
plan=f'(foreignLeavePlanView nameEq keyEq actor ambient fibers tag afterState {raw})'
data=f'(foreignLeaveReplayData (leavePlanView {plan}))'
fields=' '.join(f'(leaveReplay{x} {data})' for x in ['Component','Parent','Retired','Table'])
acc=f'(leaveReplayAccumulator {data})';view=f'(leaveReplayView {data})'
old=f'(MkFiber {fields} (Active {acc} {view}))'
new=f'(MkFiber {fields} (Unloading {acc} {view} Nothing))'
found=f'(trans (leavePlanOwnerFound {plan}) (cong Just (leaveReplayOwnerShape {data})))'
s+=f'''o19LifecyclePaperChecked nameEq keyEq (LLeave actor) tag (MkSystemState ambient fibers) afterState checked lifecycle excluded notUnloading =
  void (notUnloading
    (replace {{p = \\state => unloadingEndpoint {{name}} {{key}} {{value}} {{world}} {{error}} @{{nameEq}} actor state = True}}
      (leaveReplayAfterShape {data})
      (rewrite lookupReplacedFiber @{{nameEq}} actor
        {old}
        {new}
        fibers {found} in Refl)))
'''
s+='''o19LifecyclePaperChecked nameEq keyEq (LUnload actor) tag before afterState checked lifecycle excluded notUnloading = void (excluded Refl)
'''
p.write_text(s)
