from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19PaperBranchCompletenessSpike.idr')
s=p.read_text().replace('import DGamma.CP5O19OriginalBlockClassSpike','import DGamma.CP5ConfluenceCrossTraceSpike\nimport DGamma.CP5ConfluenceRankObservationSpike\nimport DGamma.CP5UniqueRawNameInsertions\nimport DGamma.CP5O19PairObservationSpike\nimport DGamma.CP5O19OriginalBlockClassSpike')
s+='''
||| UNCONDITIONAL ORIGINAL four-orientation classifier. Every input is an
||| existing O19 premise or an original location/word membership requested by
||| the approved static interface. Both Conditional paper-branch hypotheses
||| are now PRODUCED from the selected actual block; no paper, future row,
||| reached safety/decomposition, callback, or early-guard oracle remains.
export
0 o19OriginalClasses :
  {name, key, world, error : Type} -> {value : key -> Type} ->
  (nameEq : DecEq name) -> (keyEq : DecEq key) -> (protocol : RegistrationProtocol key value world error) ->
  {sourceOrder, targetOrder : List name} -> (swap : AdjacentActorOrderSwap name sourceOrder targetOrder) ->
  {initial, sourceFinal : SystemState name key value world error} -> (source : Transitions initial sourceFinal) ->
  (blocks : ActorBlockDecomposition name key world error value nameEq keyEq sourceOrder source) ->
  (premises : ReplayInvariantBundle name key world error value protocol nameEq keyEq source) ->
  (safety : AdjacentActorSwapSafety name key world error value protocol nameEq keyEq swap source blocks premises) ->
  UniqueRawNameInsertions name key world error value nameEq keyEq source ->
  {leftAction, rightAction : Action name key value world error} ->
  (leftOrigin : LocatedActionOccurrence leftAction source) -> (rightOrigin : LocatedActionOccurrence rightAction source) ->
  Elem leftAction (o19ActionWord (actorBlockTrace (decomposedBlock blocks (actorLeft swap) (safetyLeftInOrder safety)))) ->
  Elem rightAction (o19ActionWord (actorBlockTrace (decomposedBlock blocks (actorRight swap) (safetyRightInOrder safety)))) ->
  O19SourcePairObservation name key world error value (actorLeft swap) (actorRight swap)
    (locatedTransition leftOrigin) (locatedTransition rightOrigin)
o19OriginalClasses {leftAction} {rightAction} nameEq keyEq protocol swap source blocks premises safety unique
  leftOrigin rightOrigin leftMember rightMember =
    o19OriginalClassesConditional nameEq keyEq protocol swap source premises unique leftOrigin rightOrigin
      (o19SanctionedOriginalWords nameEq keyEq protocol swap source blocks premises safety leftAction rightAction leftMember rightMember)
'''
for side,other,member in [('Left','Right','leftMember'),('Right','Left','rightMember')]:
 origin=side.lower()+'Origin';act=side.lower()+'Action'
 block=f'(decomposedBlock blocks (actor{side} swap) (safety{side}InOrder safety))'
 obs=f'(o19OriginalBlockWord (actor{side} swap) (actor{other} swap) {block} (safety{side}DoesNotGenerate{other} safety) {act} {member})'
 s+=f'''      (o19OriginalPaperBranch nameEq keyEq (actor{side} swap) (actor{other} swap) source
        {block} {origin}
        {obs}
        (snd (alignedAppendSplit (beforeActionOccurrence {origin})
          (MoreTransitions (locatedTransition {origin}) (afterActionOccurrence {origin}))
          (replace {{p = AlignedTransitions name key world error value nameEq keyEq}}
            (sym (actionOccurrenceDecomposition {origin})) (replayAligned premises)))))
'''
p.write_text(s)
