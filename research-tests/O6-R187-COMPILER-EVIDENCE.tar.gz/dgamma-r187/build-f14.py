from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19ActualCartesianSpike.idr');s=p.read_text();name='o19ActualGlobalGrid';start=s.index('export\n0 '+name+' :');end=s.index('\n'+name+' nameEq',start)
sig=s[start:end].replace('0 '+name+' :','0 o19ActualLocalOriginPlan :');last=sig.index('  (globalCrossingPositions')
left='(decomposedBlock blocks (actorLeft swap) (safetyLeftInOrder safety))';right='(decomposedBlock blocks (actorRight swap) (safetyRightInOrder safety))'
ls=f'(transitionCount (traceBeforeBlock {left}))';rs=f'(transitionCount (traceBeforeBlock {right}))';lc=f'(actorBlockTransitionCount {left})';rc=f'(actorBlockTransitionCount {right})'
args='nameEq keyEq protocol swap source blocks premises safety unique';local=f'(o19GridPairs Z Z {lc} {rc})'
sig=sig[:last]+f'''  BlockCrossingOriginPlan name key world error value protocol nameEq keyEq source
    {left}
    {right}
    (identityActionRegistrationReplayCorrespondence source)
    (cursorDerivation (columnCursor (o19CartesianActualBlocks {args})))
    {local}'''
body=f'''
o19ActualLocalOriginPlan {args} =
  o19LocalizeGlobalPlan {left} {right}
    (globalCrossingPlan (o19ActualGlobalOriginPlan {args})) {local}
    (trans (o19ActualGlobalGrid {args})
      (sym (trans (o19GridPairsShift {ls} {rs} Z Z {lc} {rc})
        (cong2 (\\leftSource, rightSource => o19GridPairs leftSource rightSource {lc} {rc})
          (plusZeroRightNeutral {ls}) (plusZeroRightNeutral {rs})))))
'''
assert body.count('(')==body.count(')'),body
p.write_text((s+'''\n||| ACTUAL source-local Cartesian origin plan on the SAME B3 finite chain.
||| B14's offset-list equation is now DERIVED from actual numeric grid
||| equality and coordinate shifting; NO offset/plan oracle is supplied.
||| Complete/sound membership, UniqueKeys and nonempty whole-block assembly
||| remain separate certification obligations; no O19 body is claimed.
'''+sig+body).rstrip()+'\n')
