from pathlib import Path
p=Path('/Users/vyacheslavshebanov/Work/dgamma/research/DGamma/CP5O19CartesianWordRowSpike.idr');s=p.read_text()
name='o19BubbleWordRow';start=s.index('export\n0 '+name+' :');end=s.index('\n'+name+' {sourceFinal}',start)
sig=s[start:end].replace('0 '+name+' :','0 '+name+'Sites :')
for old,new in [
('  UniqueRawNameInsertions name key world error value nameEq keyEq original ->','  (unique : UniqueRawNameInsertions name key world error value nameEq keyEq original) ->'),
('  FiniteAdjacentSwapDerivation name key world error value protocol nameEq keyEq original source ->','  (prior : FiniteAdjacentSwapDerivation name key world error value protocol nameEq keyEq original source) ->'),
('  (appendTransitions earlier (appendTransitions spine (MoreTransitions right later)) = source) ->','  (decomposition : appendTransitions earlier (appendTransitions spine (MoreTransitions right later)) = source) ->'),
('  ReplayInvariantBundle name key world error value protocol nameEq keyEq source ->','  (currentPremises : ReplayInvariantBundle name key world error value protocol nameEq keyEq source) ->'),
('  UniqueRawNameInsertions name key world error value nameEq keyEq source ->','  (currentUnique : UniqueRawNameInsertions name key world error value nameEq keyEq source) ->'),
('  Either (PaperActivationStep right) (PaperOrchestrationStep right) ->','  (kind : Either (PaperActivationStep right) (PaperOrchestrationStep right)) ->')]:
 assert old in sig,old
 sig=sig.replace(old,new)
last=sig.rindex('  O19WordRow name key world error value protocol nameEq keyEq source earlier')
sig=sig[:last]+'''  (o19CrossingSites (cursorDerivation (mixedRowCursor (wordRow (o19BubbleWordRow nameEq keyEq protocol swap original blocks premises safety unique source prior earlier spine right later decomposition currentPremises currentUnique kind classes)))) =
    o19RowSites (transitionCount earlier) (transitionCount spine))'''
recursive='''nameEq keyEq protocol swap original blocks premises safety unique source prior
        (appendTransitions earlier (MoreTransitions left NoTransitions)) rest right later
        (trans (appendTransitionsAssociative earlier (MoreTransitions left NoTransitions)
          (appendTransitions rest (MoreTransitions right later))) decomposition)
        currentPremises currentUnique kind (\\step, occurs => classes step (OccursLater occurs))'''
body='''
o19BubbleWordRowSites nameEq keyEq protocol swap original blocks premises safety unique source prior earlier
  NoTransitions right later decomposition currentPremises currentUnique kind classes = Refl
o19BubbleWordRowSites nameEq keyEq protocol swap original blocks premises safety unique source prior earlier
  (MoreTransitions left rest) right later decomposition currentPremises currentUnique kind classes =
    trans (o19WordRowStepSites nameEq keyEq protocol swap original blocks premises safety unique source prior earlier left rest right later
      (o19BubbleWordRow '''+recursive+''') (classes left OccursHere))
      (cong (\\sites => sites ++ [transitionCount earlier])
        (trans (o19BubbleWordRowSites '''+recursive+''')
          (cong (\\start => o19RowSites start (transitionCount rest)) (transitionPrefixLength earlier left))))
'''
p.write_text((s+'\n||| ACTUAL arbitrary mixed row sites, not just its count: rightmost first.\n||| Structural row induction consumes D10 at each produced actual node.\n'+sig+body).rstrip()+'\n')
