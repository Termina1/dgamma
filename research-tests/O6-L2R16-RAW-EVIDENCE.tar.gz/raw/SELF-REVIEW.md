# L2R16 engineering self-review (NOT the independent mathematical gate)

- T3 is only a record TYPE; T4 supplies all thirteen proof fields (initial invariant plus twelve distinct checked edges). The old word uses nine edges; the crossed word shares six and uses three alternate edges.
- The initial state is a valid preinstalled registry, NOT a from-empty provenance result. This is permitted by the precise global-frame type, whose initial premise is registryWellFormed only.
- Root4's birth changes ordinal7→6. Root5's birth stays8. Its previous-root floor changes8→7 while its key anchor stays6; hence distances(3,0)→(2,1), total3→3. T9 independently checks these concrete computations.
- T10 constructs both roots' phases in both words, rather than merely defining a phase record TYPE. Core1 ends at Remove1/cut4, core2 at Remove2/cut6. The current contract contains no maximal-core premise.
- T14's square and T16's remaining root5 suffix frames are native checked objects, not AdmittedDistanceMove. In particular no decrease is smuggled into the square premise.
- T17's All data supplies phases for the complete old catalog and rules out earlier catalog entries; it does not assume the desired global distance frame.
- T18's only unassembled input is explicitly 0 unique : UniqueRawNameInsertions ... . The body builds every other antecedent and uses the two hypothetical decompositions to derive3=4. No unconditional refutation or whole normalization result is claimed.
- T12's failed anchorUnique implementation is absent from retained source. Its raw source and all three failed checks are archived; R87's visibility change is separately authorized and exact.
- All twelve new modules are total and contain no new holes/unsafe escapes. This review does not replace fresh compiler evidence or the parent-owned independent mathematical review.
