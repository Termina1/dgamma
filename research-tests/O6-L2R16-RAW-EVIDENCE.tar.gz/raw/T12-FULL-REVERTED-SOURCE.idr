module DGamma.L2R16AnchorDomain

import Builtin
import Prelude.Types
import Prelude.Interfaces
import Prelude.Basics
import Prelude.EqOrd
import DGamma.Calculus
import DGamma.Coeffects
import DGamma.Metatheory
import DGamma.CP3
import DGamma.CP5AvailabilityAwarePlacement
import DGamma.CP5UniqueRawNameInsertions
import DGamma.L2R2SmallStates
import DGamma.L2R3ForcedClosure
import DGamma.L2R5RootCatalog
import DGamma.L2R6ForcedScan
import DGamma.L2R6Anchors
import DGamma.L2R6FrontNormal
import DGamma.L2R6Phase
import DGamma.L2R10OrdinalData
import DGamma.L2R16AnchorStates
import DGamma.L2R16AnchorNative
import DGamma.L2R16AnchorTrace
import DGamma.L2R16AnchorTrail
import DGamma.L2R16ProductionBridge
import DGamma.L2R16AnchorUnique
import DGamma.L2R16AnchorPhases
import Data.Bool
import Data.List
import Data.List.Elem
import Data.Maybe
import Data.Nat
import Decidable.Equality
import Decidable.Decidable

%default total
%unbound_implicits off

||| Unique raw names for every located insertion in each actual word. Both
||| arbitrary occurrences are authenticated by rawInsertionNameAtLocated;
||| their counts meet at the same name-determined cut, not supplied equality.
public export
0 anchorUnique : (crossed : Bool) ->
  UniqueRawNameInsertions Nat Bool Unit String (\key => Unit)
    (fst fixtureDictionaries) (snd fixtureDictionaries) (anchorTrace crossed)
anchorUnique False = MkUniqueRawNameInsertions
  (\selected, leftParent, rightParent, leftComponent, rightComponent, left, right =>
    case the (guard : Bool ** (selected == 4) = guard) ((selected == 4) ** Refl) of
      (True ** observed) =>
        trans (replace {p = \guard => locatedActionOrdinal left = (if guard then 7 else 8)} observed
          (anchorInsertionAt False selected (locatedActionOrdinal left)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace False) selected leftParent leftComponent left)))
          (sym (replace {p = \guard => locatedActionOrdinal right = (if guard then 7 else 8)} observed
            (anchorInsertionAt False selected (locatedActionOrdinal right)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace False) selected rightParent rightComponent right))))
      (False ** observed) =>
        trans (replace {p = \guard => locatedActionOrdinal left = (if guard then 7 else 8)} observed
          (anchorInsertionAt False selected (locatedActionOrdinal left)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace False) selected leftParent leftComponent left)))
          (sym (replace {p = \guard => locatedActionOrdinal right = (if guard then 7 else 8)} observed
            (anchorInsertionAt False selected (locatedActionOrdinal right)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace False) selected rightParent rightComponent right)))))
anchorUnique True = MkUniqueRawNameInsertions
  (\selected, leftParent, rightParent, leftComponent, rightComponent, left, right =>
    case the (guard : Bool ** (selected == 4) = guard) ((selected == 4) ** Refl) of
      (True ** observed) =>
        trans (replace {p = \guard => locatedActionOrdinal left = (if guard then 6 else 8)} observed
          (anchorInsertionAt True selected (locatedActionOrdinal left)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace True) selected leftParent leftComponent left)))
          (sym (replace {p = \guard => locatedActionOrdinal right = (if guard then 6 else 8)} observed
            (anchorInsertionAt True selected (locatedActionOrdinal right)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace True) selected rightParent rightComponent right))))
      (False ** observed) =>
        trans (replace {p = \guard => locatedActionOrdinal left = (if guard then 6 else 8)} observed
          (anchorInsertionAt True selected (locatedActionOrdinal left)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace True) selected leftParent leftComponent left)))
          (sym (replace {p = \guard => locatedActionOrdinal right = (if guard then 6 else 8)} observed
            (anchorInsertionAt True selected (locatedActionOrdinal right)
          (rawInsertionNameAtLocated Nat Bool Unit String (\key => Unit)
            (anchorTrace True) selected rightParent rightComponent right)))))
