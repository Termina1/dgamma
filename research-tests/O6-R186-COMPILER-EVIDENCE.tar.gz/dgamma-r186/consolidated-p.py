import subprocess,datetime
files = [
'research/DGamma/CP5O19BodyMetadataSpike.idr',
'research/DGamma/CP5O19MixedActivationRowSpike.idr',
'research/DGamma/CP5O19MixedRowDispatcherSpike.idr',
'research/DGamma/CP5O19CartesianLengthSpike.idr',
'research/DGamma/CP5O19PairObservationSpike.idr',
'research/DGamma/CP5O19CartesianWordRowSpike.idr',
'research/DGamma/CP5O19CartesianColumnsSpike.idr',
'research/DGamma/CP5O20LinearExtensionSpike.idr',
'package']
for n,path in enumerate(files,1):
 r=subprocess.run(['python3','-I','research-tests/run-r186-check.py','P'+str(n),path])
 if r.returncode: raise SystemExit(r.returncode)
print('CONSOLIDATED P ALL PASS',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
