import subprocess, datetime
from pathlib import Path
root=Path('/Users/vyacheslavshebanov/Work/dgamma')
modules=['CP5O19BodyMetadataSpike','CP5O19MixedActivationRowSpike','CP5O19MixedRowDispatcherSpike','CP5O19CartesianLengthSpike','CP5O19PairObservationSpike','CP5O19CartesianWordRowSpike','CP5O19CartesianColumnsSpike','CP5O20LinearExtensionSpike','CP5O19OriginalBlockClassSpike']
for number,path in enumerate(['research/DGamma/'+m+'.idr' for m in modules]+['package'],1):
    result=subprocess.run(['python3','-I','research-tests/run-r186-check.py','Q'+str(number),path],cwd=root)
    if result.returncode: raise SystemExit(result.returncode)
print('CONSOLIDATED FINAL Q ALL PASS',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
