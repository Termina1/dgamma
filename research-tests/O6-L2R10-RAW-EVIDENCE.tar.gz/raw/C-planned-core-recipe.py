#!/usr/bin/env python3
"""L2R10 pure per-path core recipe copied from L2R9 and bounded to ONE path.
Original/restored native packets are reused read-only; no old assembly body
is emitted. PathCoreData is the new abstract contract. No compiler/git writes.
"""
import importlib.util,pathlib,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma-lane2')
spec=importlib.util.spec_from_file_location('native',ROOT/'research-tests/run-l2r9-fixture-recipe.py')
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
def projection(packet,index,count):
 p=packet
 for _ in range(index):p='(snd '+p+')'
 return p if index==count-1 else '(fst '+p+')'
def step(schedule,index):
 word=native.WORDS[schedule];p=native.PATHS[schedule];edge=(p[index],p[index+1],word[index]);j=native.EDGES.index(edge)
 if j<5:proof=projection('contiguityOriginalFirst',j,5)
 elif j<7:proof=projection('contiguityOriginalLast',j-5,2)
 elif j<10:raise ValueError('B4 split-path producer stopped3/3; cannot create a native edge')
 else:proof=f'(restoredEdge{j} '+('contiguityRestoredFirst' if j<=12 else 'contiguityRestoredLast')+')'
 action,tag=native.ACTIONS[word[index]]
 return f'(Fired {{before = contiguityState {p[index]}}} {{afterState = contiguityState {p[index+1]}}} %search %search ({action}) {tag} {proof})'
native.step=step

def before_core(schedule):
 t=native.trace(schedule,0,0 if schedule==0 else 1)
 for i in reversed(range(4)):t=f'(MoreTransitions {native.prefix_step(i)} {t})'
 return t

def before_trail(schedule):
 t=native.trail(schedule,0,0 if schedule==0 else 1)
 for i in reversed(range(4)):t=f'(AvailabilityStep (smallState {i}) {native.prefix_step(i)} _ {t})'
 return t

def extended(schedule,start,end):
 t=f'(ExtendedLifecycleEnd {{name = Nat}} {{key = Bool}} {{world = Unit}} {{error = String}} {{value = \\key => Unit}} {{nameEq = %search}} {{selected = 2}} {{state = contiguityState {native.PATHS[schedule][end]}}})'
 for i in reversed(range(start,end)):
  c=native.WORDS[schedule][i];st=step(schedule,i);rest=native.trace(schedule,i+1,end)
  inst=f'{{name = Nat}} {{key = Bool}} {{world = Unit}} {{error = String}} {{value = \\key => Unit}} {{nameEq = %search}} {{selected = 2}} {{first = contiguityState {native.PATHS[schedule][i]}}} {{middle = contiguityState {native.PATHS[schedule][i+1]}}} {{finalState = contiguityState {native.PATHS[schedule][end]}}}'
  if c in 'BF':t=f'(ExtendedLifecycleStep {inst} {st} {rest} Refl Refl {t})'
  elif c=='I':t=f'(ExtendedYieldedRegistrationStep {inst} {{child = 5}} {{component = smallComponent False}} {st} {rest} Refl {t})'
  elif c in 'TD':
   ctor='ExtendedChildRetireStep' if c=='T' else 'ExtendedChildRemoveStep'
   fiber='(freshFiber (smallComponent False) (ChildOf 2))'
   if c=='D':fiber=f'(retireFiber {fiber})'
   t=f'({ctor} {inst} {st} {rest} 5 {fiber} Refl Refl Refl {t})'
  else:raise ValueError('No root action in extended core')
 return t

def core(schedule):
 a,b=(0,5) if schedule==0 else (1,6)
 return f'''(MkLocatedExtendedCore {{name = Nat}} {{key = Bool}} {{world = Unit}} {{error = String}} {{value = \\key => Unit}} {{nameEq = %search}} {{actor = 2}} {{initial = smallState 0}} {{finalState = contiguityState {native.PATHS[schedule][7]}}} {{global = {native.full_trace(schedule)}}} (contiguityState {native.PATHS[schedule][a]}) (contiguityState {native.PATHS[schedule][b]})
    {before_core(schedule)}
    {native.trace(schedule,a,b)}
    {native.trace(schedule,b,7)}
    {before_trail(schedule)}
    {native.trail(schedule,a,b)}
    {native.trail(schedule,b,7)}
    {extended(schedule,a,b)} Refl)'''

PREFIX=['LBegin 0','LAdvance 0','ORetire 1','ORemove 1']
CORE=[native.ACTIONS[c][0] for c in 'IBFTD']
ROOT=native.ACTIONS['R'][0]
BARRIER=native.ACTIONS['S'][0]
def word(items):
 return '['+', '.join(items)+']'
def path_type(schedule):
 pre=PREFIX if schedule==0 else PREFIX+[ROOT]
 suf=[ROOT,BARRIER] if schedule==0 else [BARRIER]
 end=7 if schedule==0 else 17
 return f'PathCoreData (contiguityState {end}) {word(pre)} {word(CORE)} {word(suf)} {4 if schedule==0 else 5}'
def path_declaration(schedule):
 name='originalCoreData' if schedule==0 else 'restoredCoreData'
 return f"""
||| Native SINGLE-path package. Existing checked equation packets construct
||| the trail and located source-aware core simultaneously. Word/position
||| observations belong to this one path; no whole restoration is assumed.
public export
{name} : {path_type(schedule)}
{name} = MkPathCoreData
  {native.full_trace(schedule)}
  {native.full_trail(schedule)}
  {core(schedule)}
  Refl Refl Refl Refl Refl
"""
