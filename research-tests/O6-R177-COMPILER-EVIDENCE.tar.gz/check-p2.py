import datetime, json, os, pathlib, re, signal, subprocess, sys, time
ROOT = pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma')
OUT = pathlib.Path('/tmp/dgamma-r177')
unit, path = sys.argv[1:3]
assert not re.search(r'/idris2_app/idris2(?:\.so)?(?:\s|$)', subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True),re.M), 'Existing compiler; reconcile first'
command = ['idris2','--source-dir','src','--source-dir','research']
if path == 'dgamma.ipkg': command = ['idris2','--build',path]
else:
    (ROOT/path).touch()
    if path.startswith('research-tests/'): command += ['--source-dir','research-tests']
    command += [path, '--exec', os.environ['R177_PROBE_EXEC']]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT/(unit+'.source')).write_bytes((ROOT/path).read_bytes())
print('START',unit,start,' '.join(command),flush=True)
maxrss=0
with (OUT/(unit+'.log')).open('w') as log:
    p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (OUT/(unit+'.pid')).write_text(str(p.pid))
    def stop(sig,frame):
        os.killpg(p.pid,signal.SIGTERM); p.wait(); raise SystemExit(128+sig)
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    while p.poll() is None:
        time.sleep(1)
        for line in subprocess.check_output(['ps','-axo','pid,ppid,rss,command'],text=True).splitlines():
            fields=line.strip().split(None,3)
            if len(fields)==4 and fields[0].isdigit() and '/idris2_app/idris2' in fields[3]:
                maxrss=max(maxrss,int(fields[2]))
                if maxrss>80*1024*1024: stop(signal.SIGTERM,None)
text=(OUT/(unit+'.log')).read_text()
fresh=path=='dgamma.ipkg' or 'Building DGamma.'+pathlib.Path(path).stem in text
record=dict(unit=unit,path=path,command=' '.join(command),start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode,fresh=fresh,maxSampleRSSKiB=maxrss,passed=p.returncode==0 and fresh,transcript=text)
(OUT/(unit+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(text,flush=True); print('RESULT',json.dumps({k:v for k,v in record.items() if k!='transcript'}),flush=True)
