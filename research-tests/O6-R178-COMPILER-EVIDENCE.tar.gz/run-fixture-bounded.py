import subprocess,sys,signal
unit,path=sys.argv[1:]
with open('/tmp/dgamma-r178/'+unit+'.driver.log','w') as log:
 p=subprocess.Popen(['python3','-I','research-tests/run-r178-check.py',unit,path],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print('runner',p.pid,flush=True)
 try:p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  p.send_signal(signal.SIGTERM)
  p.wait(timeout=20)
 sys.exit(p.returncode)
