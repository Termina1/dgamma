from pathlib import Path
import re,sys
root=Path('/Users/vyacheslavshebanov/Work/dgamma')
name=sys.argv[1]
s=(root/'research/DGamma/CP5CurrentGenerationBirthSpike.idr').read_text()
a=s.index('0 '+name+' :');b=s.index('\n0 ',a+1)
t=s[a:b].rstrip()
t=re.sub(r'\bcurrent(\w*Owner)\b',r'retired\1',t)
t=t.replace('currentResultOwnerReplace', 'retiredResultOwnerReplace')
flag='(retired fiber)' if name in ['currentBeginOwner','currentLifecycleResultOwner'] else 'retiredFlag'
t=t.replace('CurrentResultOwner name key world error value nameEq actor', 'RetiredResultOwner name key world error value nameEq actor '+flag)
t=t.replace('CurrentResultOwner name key world error value nameEq (actionOwner action)', 'RetiredResultOwner name key world error value nameEq (actionOwner action) (retired fiber)')
t=t.replace('retiredResultOwnerReplace name key world error value nameEq actor (registry before)', 'retiredResultOwnerReplace name key world error value nameEq actor retiredFlag (registry before)')
t=re.sub(r'\b(LBeginTag|LDivertTag|LLeaveTag|LUnloadTag|LFinishTag|LRaiseTag|LIterTag)\b',r'\1 Refl',t)
# A trailing comment belongs to the original following declaration, not this one.
t=t.split('\n||| All successful lifecycle')[0].rstrip()
p=root/'research/DGamma/CP5RetiredFlagEvaluationSpike.idr'
p.write_text(p.read_text()+'\n\n'+t+'\n')
print('appended exactly',name,'=>',name.replace('current','retired',1))
