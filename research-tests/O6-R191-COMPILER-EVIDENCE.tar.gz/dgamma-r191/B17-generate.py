from pathlib import Path
import re,json
cases=[('PairedBeginStage','o20PairedActualBeginCut','CP5O20SharedBeginAdapterSpike',['leftOpening','rightOpening','pairwise']),('PairedAdvanceStage','o20PairedObservedAdvanceCut','CP5O20PairedAdvanceSpike',['leftFound','rightFound','leftResolved','rightResolved','leftRun','rightRun','leftChecked','rightChecked']),('PairedEmptyFinishStage','o20PairedObservedEmptyFinishCut','CP5O20PairedAdvanceSpike',['leftFound','rightFound','leftChecked','rightChecked']),('PairedRetireStage','o20PairedObservedRetireCut','CP5O20PairedAdvanceSpike',['leftFound','rightFound','leftChecked','rightChecked']),('PairedInsertStage','o20PairedObservedInsertCut','CP5O20PairedAdvanceSpike',['parents','leftChecked','rightChecked'])]
def split_arrows(t):
 out=[];d=0;start=0;i=0
 while i<len(t):
  c=t[i]
  if c in '([{':d+=1
  elif c in ')]}':d-=1
  if d==0 and t[i:i+2]=='->':out.append(t[start:i].strip());start=i+2;i+=1
  i+=1
 out.append(t[start:].strip());return out
base='O20AllNameCut name key world error value nameEq renaming '
def state_pair(t):
 t=t[len(base):];out=[];d=0;start=0
 for i,c in enumerate(t):
  if c in '([{':d+=1
  elif c in ')]}':d-=1
  if d==0 and c.isspace():
   if t[start:i].strip():out.append(t[start:i].strip())
   start=i+1
 if t[start:].strip():out.append(t[start:].strip())
 assert len(out)==2,out
 return out
head='''module DGamma.CP5O20PairedExecutionSpike

import DGamma.Calculus
import DGamma.Coeffects
import DGamma.Metatheory
import DGamma.CP3
import DGamma.CP5O20AllNameSynchronizationSpike
import DGamma.CP5O20SharedBeginAdapterSpike
import DGamma.CP5O20PairedAdvanceSpike
import Data.List
import Data.Maybe
import Decidable.Equality

%default total
%unbound_implicits off

||| Indexed ACTUAL paired stages. Every constructor owns two native checked
||| edges (BeginStep owns its check). Advance payloads are actual callback and
||| capability observations. No post-cut fact, preservation function, endpoint
||| equality or generated-birth triangle is stored here. Insertion/retirement
||| gaps may concern roots OR children. Remove/failure/diversion are NOT covered.
public export
data O20PairedStage :
  (name, key, world, error : Type) -> (value : key -> Type) ->
  (nameEq : DecEq name) -> (keyEq : DecEq key) -> (renaming : NameBijection name) ->
  (leftBefore, rightBefore, leftAfter, rightAfter : SystemState name key value world error) -> Type where
'''
meta=[]
for ctor,fn,mod,proofs in cases:
 text=Path('research/DGamma/'+mod+'.idr').read_text();sig=' '.join(text.split('0 '+fn+' :',1)[1].split('\n'+fn+' ',1)[0].split());args=split_arrows(sig);final=args.pop();assert final.startswith(base),(fn,final)
 built=[];fields=[];call=[];pre=None;queue=list(proofs)
 for a in args:
  if a.startswith(base):pre=state_pair(a);call.append('paired');continue
  if a.startswith('{'):built.append(a);continue
  named=re.match(r'^\(([^():]+)\s*:\s*(.*)\)$',a,re.S)
  if named:
   names=[n.strip() for n in named.group(1).split(',')];ty=named.group(2);fields.extend(names);call.extend(names)
   if ty.lstrip().startswith('lookupFiber'):a='(0 '+named.group(1).strip()+' : '+ty+')'
   built.append(a)
  else:
   n=queue.pop(0);fields.append(n);call.append(n);ty=a[1:-1] if a.startswith('(') and a.endswith(')') else a;built.append('(0 '+n+' : '+ty+')')
 assert not queue and pre is not None,(ctor,queue,pre)
 post=state_pair(final);head+='  '+ctor+' :\n    '+' ->\n    '.join(built)+' ->\n    O20PairedStage name key world error value nameEq keyEq renaming '+' '.join(pre+post)+'\n'
 meta.append(dict(constructor=ctor,function=fn,fields=fields,call=call))
Path('research/DGamma/CP5O20PairedExecutionSpike.idr').write_text(head)
Path('/tmp/dgamma-r191/B17-plumbing.json').write_text(json.dumps(meta,indent=2))
