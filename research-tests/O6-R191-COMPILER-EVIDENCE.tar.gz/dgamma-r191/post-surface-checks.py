import subprocess,pathlib
out=pathlib.Path('/tmp/dgamma-r191')
for unit,path in [('SR1', 'research-tests/DGamma/R190O20AllNameSynchronizationPositive.idr'), ('SR2', 'research/DGamma/CP5O20SafeBlockSelectionSpike.idr'), ('SR3', 'research/DGamma/CP5O20BlockMeasureSpike.idr'), ('SR4', 'research/DGamma/CP5O20SupportedReferenceSpike.idr'), ('SR5', 'research-tests/DGamma/R182O19RevisedSafetyPositive.idr'), ('SR6', 'research-tests/DGamma/R182O19RevisedSafetyNegative.idr')]:
 with (out/(unit+'.wrapper')).open('w') as f:
  p=subprocess.run(['python3','-I','research-tests/run-r191-check.py',unit,path],stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,unit
 print(unit,'PASS',flush=True)
