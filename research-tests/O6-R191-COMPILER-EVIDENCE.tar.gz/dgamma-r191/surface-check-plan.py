import subprocess,json,pathlib
out=pathlib.Path('/tmp/dgamma-r191')
for unit,name in [('SUR2','OperationalProgress'),('SUR3','OperationalDescent'),('SUR4','ReferenceDescent')]:
 with (out/(unit+'.wrapper')).open('w') as f:
  p=subprocess.run(['python3','-I','research-tests/run-r191-check.py',unit,'research/DGamma/CP5O20'+name+'Spike.idr'],stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,unit
 print(unit,'PASS',flush=True)
