import json,pathlib,subprocess,time
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
print('WAITING FOR C62 AND GUARDED B7',flush=True)
while True:
    monitor=(out/'after-prebody-fixture.monitor').read_text()
    if 'STOP:' in monitor or 'Traceback' in monitor:raise SystemExit('STOP: prerequisite fixture driver failed')
    if 'B7-1 COMMITTED; C62/B7 READY' in monitor:break
    time.sleep(5)
for source,target in [('body-runner.py','research-tests/run-r189-body.py'),('verify-final-draft.py','research-tests/run-r189-verify-evidence.py'),('C-clause-map.json','research-tests/O6-R189-CLAUSE-MAP.json')]:
    (root/target).write_bytes((out/source).read_bytes())
p=root/'research-tests/O6-R189-GRIND-SHIFT-AUDIT.md'
p.write_text(p.read_text()+'''\n## C62 and complete concrete B7 accepted checkpoint\n\nAll62 prebody validations freshly PASS, including own-source checks for\nall35 O19 modules/the three lowered O20 helpers, frozen surfaces, required\nR8/R16/R181-count7/R182 safety/adjacency regressions and seeded package.\nB7-1 then freshly PASS/guarded committed the single concrete no-oracle\nfull OperationalAdjacentBlockSwap regression on the genuine six-step trace.\nThe new public O19 body is still UNATTEMPTED at this checkpoint.\n\nV1 unchanged LocalDiamond own-source check took493.24s. Largest sampled\nRSS49,824,992KiB (~47.52GiB), below48-GiB watchdog; no interruption.\nNo cache was deleted. Package success is SEEDED, NOT207 forced source rebuilds.\nCompiler-free scan also finds no protected-hole name reference in any of\nthe35 O19 or three lowered O20 helper module bodies.\n\nInstalling the exact one-body runner now: it independently requires52\nguarded mechanical commits, the accepted A/B/B7 proof receipts, all62\ncurrent-source validation hashes, clean tree and the exact5-hole frozen\ncensus BEFORE touching O19. On failure it retains the snapshot/transcript,\nfully restores the committed source, then stops/gates; no automatic retry.\n''')
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-artifact-commit.py'),'B7-1','audit(r189): committed fresh C62/B7 checkpoint and exact gated body runner','research-tests/run-r189-body.py','research-tests/run-r189-verify-evidence.py','research-tests/O6-R189-CLAUSE-MAP.json','research-tests/O6-R189-GRIND-SHIFT-AUDIT.md'],cwd=root,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
with (out/'C-checkpoint-archive.monitor').open('w') as log:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-archive.py'),'R189','8e133ed5',head],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
with (root/'research-tests/O6-R189-EVIDENCE-VERIFICATION.json').open('w') as report,(out/'C-checkpoint-verification.errors').open('w') as errors:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-verify-evidence.py'),'--expected-a','9','--expected-b','6','--expected-mechanical','52','--expected-bodies','0','--expected-validations','62'],cwd=root,stdout=report,stderr=errors,check=True)
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-artifact-commit.py'),'B7-1','audit(r189): independently verified prebody ledger archive and prerequisite boundary','research-tests/O6-R189-COMPILER-EVIDENCE.tar.gz','research-tests/O6-R189-COMPILER-LEDGER.json','research-tests/O6-R189-EVIDENCE-VERIFICATION.json'],cwd=root,check=True)
print('C62/B7 CHECKPOINT ARCHIVE INDEPENDENTLY VERIFIED AND COMMITTED; BODY NOT ATTEMPTED',flush=True)
