import pathlib,subprocess
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
for unit in ['M30-2','M31-1','M32-1','I17-1','I18-1','I19-1']:
    print('START',unit,flush=True)
    with (out/(unit+'.monitor')).open('w') as log:
        result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-mechanical.py'),unit],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise SystemExit('STOP/GATE '+unit+' exit '+str(result.returncode))
    print('COMMITTED',unit,flush=True)
print('REHOME COMPLETE',flush=True)
