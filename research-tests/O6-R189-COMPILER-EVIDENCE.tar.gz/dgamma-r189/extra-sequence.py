import pathlib, subprocess
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
for unit in ['M'+str(n)+'-1' for n in range(28,33)]+['I'+str(n)+'-1' for n in range(17,20)]:
    print('START',unit,flush=True)
    with (out/(unit+'.monitor')).open('w') as log:
        result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-mechanical.py'),unit],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise SystemExit('STOP/GATE '+unit+' exit '+str(result.returncode))
    print('COMMITTED',unit,flush=True)
print('ALL FIVE EXTRA MOVES/THREE IMPORT SWITCHES COMMITTED',flush=True)
