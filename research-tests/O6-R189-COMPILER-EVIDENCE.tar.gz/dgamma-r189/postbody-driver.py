import json,pathlib,subprocess
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
assert 'C62/B7 CHECKPOINT ARCHIVE INDEPENDENTLY VERIFIED AND COMMITTED' in (out/'C-checkpoint.monitor').read_text()
verification=json.loads((root/'research-tests/O6-R189-EVIDENCE-VERIFICATION.json').read_text())
assert verification['validValidations']==62 and verification['bodyInvocations']==0 and verification['mechanicalReceipts']==52
print('START EXACT GATED BODY O19-1',flush=True)
with (out/'O19-1.monitor').open('w') as log:
    result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-body.py'),'O19-1'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:raise SystemExit('STOP/GATE: O19 body runner failed; inspect exact monitor and rollback')
print('O19-1 GUARDED COMMITTED; START PUBLIC REGRESSION B8-1',flush=True)
target='research-tests/DGamma/R189O19OperationalAssemblyPositive.idr'
old=(root/target).read_bytes();new=old+(out/'B8-public-fixture.append').read_bytes()
assert b'r189IndependentPublicSwap' not in old
(root/target).write_bytes(new)
with (out/'B8-1.monitor').open('w') as log:
    result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-check.py'),'B8-1',target],cwd=root,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:
    assert (root/target).read_bytes()==new
    (root/target).write_bytes(old)
    raise SystemExit('STOP/GATE: rejected B8 snapshot retained; fixture restored to committed B7')
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-commit.py'),'B8-1','test(o19): exercise the closed public producer on genuine full trace (R189 B8-1)'],cwd=root,check=True)
print('B8-1 GUARDED COMMITTED; START ALL21 POSTBODY VALIDATIONS',flush=True)
with (out/'postbody-validation.monitor').open('w') as log:
    result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-final-validation.py'),'postbody'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:raise SystemExit('STOP/GATE: postbody regression failure')
print('O19 CLOSED, B8 COMMITTED, ALL21 POSTBODY VALIDATIONS PASSED; IMMEDIATE CLOSURE AUDIT/GATE',flush=True)
