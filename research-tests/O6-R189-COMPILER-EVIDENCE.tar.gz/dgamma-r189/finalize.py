import datetime,hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
print('WAITING FOR POSTBODY REGRESSIONS; NO OTHER PROOF WORK',flush=True)
while True:
    text=(out/'postbody-driver.monitor').read_text()
    if 'STOP/GATE:' in text or 'Traceback' in text:raise SystemExit('STOP: body/postbody driver failed')
    if 'ALL21 POSTBODY VALIDATIONS PASSED; IMMEDIATE CLOSURE AUDIT/GATE' in text:break
    time.sleep(5)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
def sha(data):return hashlib.sha256(data).hexdigest()
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
assert not re.search(r'/idris2_app/idris2(?:\.so)?(?:\s|$)',subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True))
with (out/'final-frozen.monitor').open('w') as log:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-frozen-audit.py'),str(out/'final-frozen.json')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
with (out/'final-clause-map.json').open('w') as target:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-clause-map.py')],cwd=root,stdout=target,check=True)
frozen=json.loads((out/'final-frozen.json').read_text());assert frozen['O19Closed'] and frozen['split']==[1,2,0,0,1]
records=[json.loads(line) for line in (out/'ledger.jsonl').read_text().splitlines()]
assert len(records)==155 and sum(r['passed'] for r in records)==153
assert [r['unit'] for r in records if not r['passed']]==['A3-1','M30-1']
assert sum(r['expectedDiagnostic'] is not None for r in records)==4
assert not any(r['interrupted'] for r in records)
receipts=[json.loads(line) for line in (out/'commit-receipts.jsonl').read_text().splitlines()]
body=next(r for r in receipts if r['event']=='GUARDED BODY COMMIT')
assert body['resultingCommitHash']=='d8025345ed04c231211ca464e1dbef2ffd6b2c32'
clause=json.loads((out/'final-clause-map.json').read_text());location=next(r for r in clause['protected'] if r['declaration']=='operationalAdjacentBlockSwapSpike')
pre=json.loads((out/'prebody-validation-plan.json').read_text());post=json.loads((out/'postbody-validation-plan.json').read_text())
assert len(pre)==62 and len(post)==21
for source,target in [('final-frozen.json','O6-R189-FROZEN-AUDIT.json'),('final-clause-map.json','O6-R189-CLAUSE-MAP.json')]:
    (root/'research-tests'/target).write_bytes((out/source).read_bytes())
(root/'research-tests/O6-R189-VALIDATION-PLAN.json').write_text(json.dumps(dict(prebody=pre,postbody=post,allSourceChecksRequireOwnBuildingLine=True,packageBuildsAreSeededNot207ForcedSourceRebuilds=True),indent=2)+'\n')
byUnit={r['unit']:r for r in records}
p=root/'research-tests/O6-R189-GRIND-SHIFT-AUDIT.md'
p.write_text(p.read_text()+f'''\n## Status\n\n**O19 CLOSED**, exact original statement, fresh O19-1 PASS1/3 and immediate\nguarded commit `{body['resultingCommitHash']}`. Body merely applies the\nproved actual same-chain assembler; the final arguments are deliberately\nsafety then uniqueness at the assembler, uniqueness then safety publicly.\nNo extra premise/field, no label-only surrogate, no invented generated-\nmatching premise, no desired replay/decomposition supplied as an oracle.\n\nFully proved in this shift: full actual reached ActorBlockDecomposition\n(A1–A9); same-chain external relation/endpoint/full bundle/complete operational\nrecord (B2–B6); concrete direct and public full-record regressions (B7/B8);\nand the exact public O19 producer. All proof additions are quantity0,\n%default total/%unbound_implicits off, with no unsafe escape hatch.\n32 existing declarations were byte-identically rehomed (not newly proved);\n19 exact import substitutions close the transitive cycle. Three private\nsupport-truth helpers stayed byte-identical in CrossTrace.\n\nCensus **4 = 1/2/0/0/1**, in CanonicalSort/CrossTrace/DeletionChain/\nLocalDiamond/RenamingComposition order. O17/O20/O21/O24 remain explicitly\nopen and UNCHANGED; full Thm73 is NOT claimed. No production promotion.\nNo third specification gap was discovered; only the gated transitive import\nomission, approved separator normalization and rejected extractor error.\nNext action is the mandatory independent supervisor/reviewer closure gate;\nno other hole work or extra proof attempt is authorized by this completion.\n\n### Final validation/evidence\n\n155 exact compiler/source/package records:153 accepted,2 rejected\n(A3-1/M30-1),0 interruptions,0 exhausted seams,0 invocation relabeling.\n16 single-declaration proof/test source commits,52 guarded mechanical\ncommits and1 guarded body commit; all source-changing commits receipted.\n83 fresh validations =62 prebody +21 postbody, with4 expected-diagnostic\nnegative checks (two per phase); all validation records accepted.\nB8 public regression fresh PASS1/3 in{byUnit['B8-1']['seconds']:.2f}s;\nO19 body check{byUnit['O19-1']['seconds']:.2f}s. Both full-record regression\nproofs are compile-time Idris checks, NOT a claimed JS runtime test.\nTwo SEEDED207-module package builds passed: V62 in{byUnit['V62']['seconds']:.2f}s\nand V83 in{byUnit['V83']['seconds']:.2f}s. No cache deletion; maximum sampled\nRSS{max(r['maxSampleRSSKiB'] for r in records):,}KiB, below48-GiB watchdog.\n\nOld O19 hole body line727 is now closed body line{location['newBodyLine']}\n(two body lines), signature starts{location['newSignatureLine']}; full\nsource-derived32-declaration old→new line map is committed separately.\nO19 statement SHA256 `{location['signatureSHA256']}` unchanged.\nFrozen adjacentSwapSuffixSpike full SHA256\n`{frozen['adjacentFullSHA256']}`; statement SHA256\n`{frozen['adjacentStatementSHA256']}`.\nCP3 blob `{frozen['CP3Blob']}`; production/package diff empty vs34b21c9;\nLocalDiamond and every other protected declaration unchanged vs8e133ed5.\nTracked tree/stage clean; only permitted paper/ and immutable review file\nuntracked. Final archive cannot contain its own closing commit-time receipt;\nthat exact live receipt/commit/hash are separately reported at the gate.\n\nIndependent verification command:\n`python3 -I research-tests/run-r189-verify-evidence.py --expected-a9\n --expected-b7 --expected-mechanical52 --expected-bodies1\n --expected-validations83` (spaces between option/value are required;\nthe recorded actual command uses them). Final frozen audit and verifier\nare rerun compiler-free after the evidence commit.\n''')
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-artifact-commit.py'),'V83','audit(r189): O19 closed with83 fresh validations and exact frozen clause status','research-tests/O6-R189-GRIND-SHIFT-AUDIT.md','research-tests/O6-R189-CLAUSE-MAP.json','research-tests/O6-R189-FROZEN-AUDIT.json','research-tests/O6-R189-VALIDATION-PLAN.json'],cwd=root,check=True)
head=git('rev-parse','HEAD').strip()
with (out/'final-archive.monitor').open('w') as log:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-archive.py'),'R189','8e133ed5',head],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
verify=['python3','-I',str(root/'research-tests/run-r189-verify-evidence.py'),'--expected-a','9','--expected-b','7','--expected-mechanical','52','--expected-bodies','1','--expected-validations','83']
with (root/'research-tests/O6-R189-EVIDENCE-VERIFICATION.json').open('w') as report,(out/'final-verification.errors').open('w') as errors:
    subprocess.run(verify,cwd=root,stdout=report,stderr=errors,check=True)
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-artifact-commit.py'),'V83','audit(r189): final independently verified closure ledger archive and receipts','research-tests/O6-R189-COMPILER-EVIDENCE.tar.gz','research-tests/O6-R189-COMPILER-LEDGER.json','research-tests/O6-R189-EVIDENCE-VERIFICATION.json'],cwd=root,check=True)
with (out/'final-verification-rerun.json').open('w') as report:
    subprocess.run(verify,cwd=root,stdout=report,check=True)
with (out/'gate-frozen.monitor').open('w') as log:
    subprocess.run(['python3','-I',str(root/'research-tests/run-r189-frozen-audit.py'),str(out/'gate-frozen.json')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
assert not git('diff','--name-only').strip() and not git('diff','--cached','--name-only').strip()
assert not git('diff','--check','8e133ed5').strip()
ledger=json.loads((root/'research-tests/O6-R189-COMPILER-LEDGER.json').read_text())
closing=json.loads((out/'commit-receipts.jsonl').read_text().splitlines()[-1])
summary=dict(head=git('rev-parse','HEAD').strip(),bodyCommit=body['resultingCommitHash'],census=frozen['split'],records=len(records),accepted=153,rejected=['A3-1','M30-1'],validations=83,archiveSHA256=ledger['evidenceArchiveSHA256'],archive=ledger['evidenceArchive'],closingReceipt=closing,protectedLocation=location,changedFiles=git('diff','--name-only','8e133ed5').splitlines(),noStagedFiles=True,trackedTreeClean=True,completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('FINAL CLOSURE EVIDENCE COMMITTED/INDEPENDENTLY VERIFIED; IMMEDIATE SUPERVISOR GATE',json.dumps(summary),flush=True)
