import pathlib, subprocess
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma')
out=pathlib.Path('/tmp/dgamma-r189')
for number in range(2,28):
    unit='M'+str(number)+'-1'
    print('START',unit,flush=True)
    with (out/(unit+'.monitor')).open('w') as log:
        result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-mechanical.py'),unit],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit('STOP/GATE '+unit+' exit '+str(result.returncode))
    print('COMMITTED',unit,flush=True)
print('ALL27 MECHANICAL MOVES COMMITTED',flush=True)
