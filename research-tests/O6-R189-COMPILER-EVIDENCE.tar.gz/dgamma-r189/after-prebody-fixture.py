import datetime,json,pathlib,re,subprocess,time
root=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma');out=pathlib.Path('/tmp/dgamma-r189')
print('WAITING ONLY FOR ALL62 PREBODY RECORDS',flush=True)
while not (out/'prebody-validation-complete.json').exists():
    monitor=(out/'prebody-validation.monitor').read_text()
    if 'STOP:' in monitor or 'Traceback' in monitor:raise SystemExit('STOP: prebody validation failed, no fixture edit')
    assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime(2026,9,8,15,9,50,tzinfo=datetime.timezone.utc)
    time.sleep(5)
complete=json.loads((out/'prebody-validation-complete.json').read_text());assert len(complete['invocations'])==62
for unit in complete['invocations']:
    record=json.loads((out/(unit+'.json')).read_text());assert record['passed'] and record['fresh'] and not record['interrupted']
assert not subprocess.check_output(['git','diff','--name-only'],cwd=root).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root).strip()
assert not re.search(r'/idris2_app/idris2(?:\.so)?(?:\s|$)',subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True))
target='research-tests/DGamma/R189O19OperationalAssemblyPositive.idr'
assert not (root/target).exists()
(root/target).write_bytes((out/'R189O19OperationalAssemblyPositive.idr').read_bytes())
print('START B7-1',flush=True)
with (out/'B7-1.monitor').open('w') as log:
    result=subprocess.run(['python3','-I',str(root/'research-tests/run-r189-check.py'),'B7-1',target],cwd=root,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:raise SystemExit('STOP: B7-1 fixture rejected; inspect retained snapshot/record')
subprocess.run(['python3','-I',str(root/'research-tests/run-r189-commit.py'),'B7-1','test(o19): concrete full actual operational swap regression (R189 B7-1)'],cwd=root,check=True)
print('B7-1 COMMITTED; C62/B7 READY; BODY NOT ATTEMPTED',flush=True)
