import json, pathlib, subprocess
ROOT=pathlib.Path('/Users/vyacheslavshebanov/Work/dgamma')
OUT=pathlib.Path('/tmp/dgamma-r193')
TARGET='research-tests/DGamma/R193InstalledBlockResolverPositive.idr'
for unit, symbol, previous, tag, action in [
 ('E62','r193FrameStart','r193FrameBefore','LBeginTag','LBegin 2'),
 ('E63','r193FrameChild','r193FrameStart','OInsertTag','OInsert 3 (ChildOf 2) emptyConsumerComponent'),
 ('E64','r193FrameEnd','r193FrameChild','LFinishTag','LAdvance 2'),
 ('E65','r193FrameRightStart','r193FrameEnd','LBeginTag','LBegin 1')]:
    invocation=unit+'-1'
    assert not (OUT/(invocation+'.json')).exists()
    source=ROOT/TARGET
    addition='\npublic export\n'+symbol+' : SystemState Nat ToyKey ToyValue ToyRuntime String\n'+symbol+' = fromMaybe '+previous+' (applyTagged '+tag+' ('+action+') '+previous+')\n'
    assert symbol+' :' not in source.read_text()
    source.write_text(source.read_text()+addition)
    with (OUT/(invocation+'.console')).open('w') as console:
        result=subprocess.run(['python3','-I',str(ROOT/'research-tests/run-r193-check.py'),invocation,TARGET],cwd=ROOT,stdout=console,stderr=subprocess.STDOUT)
    assert result.returncode==0 and json.loads((OUT/(invocation+'.json')).read_text())['passed'], 'STOP on first rejected attempt; inspect preserved console/source'
    subprocess.run(['python3','-I',str(ROOT/'research-tests/run-r193-commit.py'),invocation,'R193 '+unit+': executable native block-fixture state '+symbol],cwd=ROOT,check=True)
print('FOUR NATIVE STATE UNITS PASSED AND GUARDED COMMITTED',flush=True)
